package com.example.modaljajan.view.signup
data class Email(
    val email: String
)
