package com.example.modaljajan.ui.addReview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.modaljajan.R

class AddReviewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_review)
    }
}