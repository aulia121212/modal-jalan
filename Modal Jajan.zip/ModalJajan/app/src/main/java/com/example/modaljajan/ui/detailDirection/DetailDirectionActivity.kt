package com.example.modaljajan.ui.detailDirection

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.modaljajan.R

class DetailDirectionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_direction)
    }
}